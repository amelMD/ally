const axios = require("axios");

async function smartContract(message) {
  try {
    const response = await axios.post(
      "https://smart-contract-gpt.vercel.app/api/chat",
      {
        messages: [{ content: message, role: "user" }],
      },
    );
    return response.data;
  } catch (error) {
    throw error;
  }
}

module.exports = smartContract;
