const axios = require("axios");

async function capcut(url) {
  try {
    const response = await axios.post("https://api.teknogram.id/v1/capcut", {
      url,
    });
    return response.data;
  } catch (error) {
    throw error;
  }
}

module.exports = { capcut };
